package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class twoActivity extends AppCompatActivity {
    User user;
    TextView name;
    TextView lastName;
    TextView startingLocation;
    TextView endLocation;
    TextView startHour;
    TextView startMin;
    TextView endHour;
    TextView endMin;
    TextView startHour1;
    TextView startMin1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two);
        name = findViewById(R.id.name);
        lastName = findViewById(R.id.lastName);
        startingLocation = findViewById(R.id.startingLocation);
        endLocation = findViewById(R.id.endLocation);
        startHour = findViewById(R.id.startHour);
        endMin = findViewById(R.id.endMin);
        startMin = findViewById(R.id.startMin);
        endHour = findViewById(R.id.endHour);
        startHour1 = findViewById(R.id.startHour1);
        startMin1 = findViewById(R.id.startMin1);

        Bundle bundleIntent = getIntent().getExtras();
        if (bundleIntent != null) {
            user = (User) bundleIntent.getSerializable(User.class.getSimpleName());
            name.setText(user.getName());
            lastName.setText(user.getLastName());
            startHour.setText(user.getHour1());
            startMin.setText(user.getMin1());
            startHour1.setText(user.getHour1());
            startMin1.setText(user.getMin1());
            endHour.setText(user.getHour2());
            endMin.setText(user.getMin2());
            name.setText(user.getName());
            startingLocation.setText(user.getStartingLocation());
            endLocation.setText(user.getEndLocation());
        }
    }
}